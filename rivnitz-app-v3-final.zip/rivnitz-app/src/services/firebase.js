/**
 * Firebase Service
 * Initializes Firebase app, Auth, Firestore, and Storage.
 * Import from here throughout the app — never re-initialize.
 */

import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { getMessaging } from 'firebase/messaging';
import Constants from 'expo-constants';

const firebaseConfig = {
  apiKey:            process.env.FIREBASE_API_KEY,
  authDomain:        process.env.FIREBASE_AUTH_DOMAIN,
  projectId:         process.env.FIREBASE_PROJECT_ID,
  storageBucket:     process.env.FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
  appId:             process.env.FIREBASE_APP_ID,
  measurementId:     process.env.FIREBASE_MEASUREMENT_ID,
};

const app  = initializeApp(firebaseConfig);

export const auth      = getAuth(app);
export const db        = getFirestore(app);
export const storage   = getStorage(app);

export default app;

// ─── Firestore Collection References ──────────────────────────────
// Use these constants everywhere instead of hardcoding strings.
export const COLLECTIONS = {
  USERS:          'users',
  VIDEOS:         'videos',
  COMMUNITY:      'community_posts',
  AI_SESSIONS:    'ai_sessions',
  AI_ESCALATIONS: 'ai_escalations',
  PRAYER_REQUESTS:'prayer_requests',
  LIVE_SESSIONS:  'live_sessions',
  NOTIFICATIONS:  'notifications',
  DONATIONS:      'donations',
  DAILY_TASKS:    'daily_tasks',

  // ─── Knowledge Base (admin-controlled AI brain) ───────────────
  AI_KNOWLEDGE:   'ai_knowledge',   // individual teaching entries
  AI_CONFIG:      'ai_config',      // system_prompt doc + behavior doc
};
